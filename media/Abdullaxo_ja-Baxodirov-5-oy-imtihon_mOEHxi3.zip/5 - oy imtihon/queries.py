from database import execute_query

def create_tables() -> bool | None:
    try:
        tweets = """
        CREATE TABLE IF NOT EXISTS tweets(
          id SERIAL PRIMARY KEY,
          user_id VARCHAR(255) NOT NULL,
          full_name VARCHAR(255) NOT NULL,
          created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        )"""
        
        Tweets_table = """
    CREATE TABLE Tweets (
    id SERIAL PRIMARY KEY,        
    user_id INT NOT NULL,          
    content TEXT NOT NULL,         
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
    likes INT DEFAULT 0,           
    retweets INT DEFAULT 0,        
    FOREIGN KEY (user_id) REFERENCES Users(id)
)"""

        
        users = """
    CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(128) NOT NULL,
    password VARCHAR(128) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_login SMALLINT NOT NULL DEFAULT 0,
    status SMALLINT NOT NULL DEFAULT 0
      )"""
        
        send_verification_codes = """
    CREATE TABLE IF NOT EXISTS verification_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(128) NOT NULL,
    code INT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)"""
        


        execute_query(query=tweets)
        execute_query(query=users)
        execute_query(query=send_verification_codes)
        return True
    except Exception as e:
        print(e)


def create_tables():
    print("Creating necessary tables...") 

def logout_all():
    print("Logging out from all devices...")


def add_money_query(user_id: int,full_name: str,summa: int):
     try:
          query = """
          INSERT INTO moneys(user_id,full_name,summa)
          VALUES(%s,%s,%s)"""
          execute_query(query=query,params=(user_id,full_name,summa,))
          return True
     except Exception as e:
          print(e)

def get_all_moneys(user_id:int):
     try:
          query = """
          SELECT * FROM moneys WHERE user_id = %s"""
          return execute_query(query=query,params=(user_id,),fetch="all")
     
     except Exception as e:
          print(e)

def update_money_query(user_id:int,money_id: int , summa: int):
     try:
          query = """
               UPDATE moneys SET summa = %s WHERE id = %s and user_id = %s"""
          execute_query(query=query,params=(summa,money_id,user_id,))
          return True
     except Exception as e:
          print(e)


def get_money_query(user_id: int,money_id: int):
     try:
          query = """
               SELECT * FROM moneys WHERE user_id = %s and id = %s"""
          return execute_query(query=query,params=(user_id,money_id,),fetch="one")
     except Exception as e:
          print(e)


def delete_money_query(user_id: int,money_id: int):
     try:
          query = """
               DELETE FROM moneys WHERE id = %s and user_id = %s"""
          execute_query(query=query,params=(money_id,user_id,))
          return True
     except Exception as e:
          print(e)




def get_user_by_user_name(user_name:str):
     try:
          query = """
               SELECT * FROM users WHERE user_name = %s"""
          return execute_query(query=query,params=(user_name,),fetch="one")
     
     except Exception as e:
          print(e)


def add_user_query(params: tuple) -> bool | None:
    try:
        query = """
        INSERT INTO users (full_name, email,password)
        VALUES (%s, %s,%s)
        """

        execute_query(query=query, params=params)
        return True
    except Exception as e:
        print(e)


def get_user_code(email:str,code: int):
     try:
          query = """
               SELECT * FROM verification_codes WHERE email = %s and code = %s"""
          return execute_query(query=query,params=(email,code,),fetch="one")
     
     except Exception as e:
          print(e)


def add_verification_code(email: str,code:int):
      try:
        query = """
        INSERT INTO verification_codes (email,code)
        VALUES (%s, %s)
        """
        execute_query(query=query, params=(email,code,))
        return True
      
      except Exception as e:
        print(e)


def update_user_status(email:str,status:int):
     try:
          query = """
               UPDATE users SET status = %s WHERE email = %s"""
          execute_query(query=query,params=(status,email,))
          return True
     except Exception as e:
          print(e)
          return False

     
def update_user_is_login(email:str,is_login:int):
     try:
          query = """
               UPDATE users SET is_login = %s WHERE email = %s"""
          execute_query(query=query,params=(is_login,email,))
          return True
     except Exception as e:
          print(e)
          return False
     
def get_active_user():
     try:
          query = """
     SELECT * FROM users WHERE is_login = 1"""
          return execute_query(query=query,fetch="one")
     except Exception as e:
          print(e)


def logut_all():
     try:
          query = """
               UPDATE users SET is_login = 0 WHERE is_login = 1"""
          execute_query(query=query)
          return True
     except Exception as e:
          print(e)
          return False