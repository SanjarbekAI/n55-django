
def show_auth_menu():
    print("Auth menu:")
    print("1. Register")
    print("2. Login")
    print("3. Exit")

def show_main_menu():
    print("Main menu:")
    print("1. Show all tweets")
    print("2. Create new tweet")
    print("3. Update my own tweet")
    print("4. Delete my own tweet")
    print("5. Show only my tweets")
    print("6. Logout")


