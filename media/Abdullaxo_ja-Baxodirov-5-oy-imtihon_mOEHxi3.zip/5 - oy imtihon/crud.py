import queries


def create_tweet(tweets, username):
    content = input("Enter your tweet: ")
    tweets.append({"author": username, "content": content})
    print("Tweet created successfully.")

def show_tweets(tweets, username):
    print("\nAll Tweets:")
    for idx, tweet in enumerate(tweets, 1):
        print(f"{idx}. {tweet['author']}: {tweet['content']}")

def update_tweet(tweets, username):
    print("\nYour Tweets:")
    user_tweets = [t for t in tweets if t['author'] == username]
    if user_tweets:
        for idx, tweet in enumerate(user_tweets, 1):
            print(f"{idx}. {tweet['content']}")
        try:
            idx_to_update = int(input("Select the tweet number to update: ")) - 1
            if 0 <= idx_to_update < len(user_tweets):
                new_content = input("Enter new content: ")
                user_tweets[idx_to_update]['content'] = new_content
                print("Tweet updated successfully.")
            else:
                print("Invalid tweet selection.")
        except ValueError:
            print("Invalid input. Please enter a number.")

def delete_tweet(tweets, username):
    print("\nYour Tweets:")
    user_tweets = [t for t in tweets if t['author'] == username]
    if user_tweets:
        for idx, tweet in enumerate(user_tweets, 1):
            print(f"{idx}. {tweet['content']}")
        try:
            idx_to_delete = int(input("Select the tweet number to delete: ")) - 1
            if 0 <= idx_to_delete < len(user_tweets):
                tweet_to_remove = user_tweets[idx_to_delete]
                tweets.remove(tweet_to_remove)
                print("Tweet deleted successfully.")
            else:
                print("Invalid tweet selection.")
        except ValueError:
            print("Invalid input. Please enter a number.")





def add_money():
    full_name = input("Qarz olgan insonigiz to'liq ism familyasi: ")
    user_id = queries.get_active_user()[0]
    summa = float(input("Miqdori (so'mda): "))
    if queries.add_money_query(user_id=user_id,full_name=full_name,summa=summa):
        return True
    return False


def show_moneys():
    user_id = queries.get_active_user()[0]
    moneys = queries.get_all_moneys(user_id=user_id)
    message = f"\nSizning qarzlaringiz: {90 * '_'}\n\n"
    if moneys:
        for money in moneys:
            message += f"\nID: {money[0]}\nIsm Familyasi: {money[2]}\nQarzingiz: {money[3]} so'm\nOlgan vaqtingiz: {money[4]}\n\n{90 * '_'}"
        return message
    
    else:
        message = "Qarzlaringiz mavjud emas!"
        return message
    
def update_money():
    user_id = queries.get_active_user()[0]
    money_id = int(input("Qaysi qarzingizni yopmoqchisiz id sini kiriting: "))
    money = queries.get_money_query(user_id=user_id,money_id=money_id)
    if money:
        summa = float(input(f"\nSizning {money[2]} dan, {money[3]} so'm qarzingiz bor!\nQancha miqdorini berdingiz so'mda: "))
        if summa < money[3]:
            hisobla = float(money[3]) - summa
            if queries.update_money_query(user_id=user_id,money_id=money_id,summa=hisobla):
                return (f"Bergan pulingiz qarzingizdan minus qilindi. Qolgan qarzingiz: {hisobla} so'm")
        else:
            return ("Bergan pulingiz qarzingizdan katta bo'lishi mumkin emas!")
    else:
        return ("Bunday id raqam mavjud emas!")


def delete_money():
    user_id = queries.get_active_user()[0]
    money_id = int(input("Qaysi qarzingizni to'liq yopmoqchisiz idsini kiriting: "))
    if queries.get_money_query(user_id=user_id,money_id=money_id):
        if queries.delete_money_query(user_id=user_id,money_id=money_id):
            coniform = input(f"Rostan ham {money_id} id ostidagi qarzingizni to'liq yopmoqchimisiz: (h/y) ")
            if coniform == 'h':
                return ("Qarzingiz to'liq yopildi va bazadan o'chirildi")
            else:
                return ("Bekor qilindi")
    else:
        return("Bunday id mavjud emas.")
                
