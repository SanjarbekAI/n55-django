import datetime

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import threading

import queries
import utils

import getpass

def send_verfication_code(email: str,code:int):
    sender_email = "sanjarbekwork@gmail.com"
    password = "llzc ngfi szjs djeh"

    subject = "Verification Code"
    body = f"Your verfication code: {code}"
    
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = email
    message["Subject"] = subject
    message.attach(MIMEText(body,"plain"))

    try:
        server = smtplib.SMTP("smtp.gmail.com",587)
        server.starttls()
        server.login(sender_email,password)
        server.sendmail(sender_email,email,message.as_string())
        server.quit()
    except Exception as e:
        print(e)

users = {}
tweets = {}

current_user = None

def register():
    username = input("Enter username: ")
    password = input("Enter password: ")
    print(f"User '{username}' registered successfully.")
    return username, password

def login():
    email = input("Enter email address: ")
    password = input("Enter password: ")
    print(f"Welcome back, {email}!")
    return email