import menu_text
import crud
from queries import create_tables,logut_all
import app

current_user = None
tweets = []

def auth_menu():
    while True:
        menu_text.show_auth_menu()
        choice = input("Select an option: ")

        if choice == '1':
            username, password = app.register()
            current_user = username
        elif choice == '2':
            email = app.login()
            current_user = email
            main_menu(current_user)
        elif choice == '3':
            print("Goodbye...")
            break
        else:
            print("Invalid option. Please try again.")

def main_menu(username):
    while True:
        menu_text.show_main_menu()
        choice = input("Select an option: ")

        if choice == '1':
            crud.show_tweets(tweets, username)
        elif choice == '2':
            crud.create_tweet(tweets, username)
        elif choice == '3':
            crud.update_tweet(tweets, username)
        elif choice == '4':
            crud.delete_tweet(tweets, username)
        elif choice == '5':
            crud.show_tweets(tweets, username)
        elif choice == '6':
            print("Logging out...")
            break
        else:
            print("Invalid option. Please try again.")

if __name__ == "__main__":
    create_tables() 
    auth_menu()




# def auth_menu():
#     while True:
#         print("Auth menu:")
#         print("1. Register | username, password")
#         print("2. Login")
#         print("3. Exit")
        
#         choice = input("Select an option: ")
        
#         if choice == '1':
#             username = input("Enter user name: ")
#             password = input("Enter password: ")
#             print(f"User '{username}' registered successfully.")
#         elif choice == '2':
#             email = input("Enter email address: ")
#             password = input("Enter password: ")
#             print(f"Welcome back, {email}!")
#             main_menu(username)
#         elif choice == '3':
#             print("Hayer...")
#             break
#         else:
#             print("Invalid option. Please try again.")


# def main_menu(username):
#     tweets = []
#     while True:
#         print("Main menu:")
#         print("1. Show all tweets")
#         print("2. Create new tweet")
#         print("3. Update my own tweet")
#         print("4. Delete my own tweet")
#         print("5. Show only my tweets")
#         print("6. Logout")
        
#         choice = input("Select an option: ")
        
#         if choice == '1':
#             if tweets:
#                 print("\nAll Tweets:")
#                 for idx, tweet in enumerate(tweets, 1):
#                     print(f"{idx}. {tweet['author']}: {tweet['content']}")
#             else:
#                 print("No tweets available.")

#         elif choice == '2':
#             content = input("Enter your tweet: ")
#             tweets.append({"author": username, "content": content})
#             print("Tweet created successfully.")

#         elif choice == '3':
#             print("\nYour Tweets:")
#             user_tweets = [t for t in tweets if t['author'] == username]
#             if user_tweets:
#                 for idx, tweet in enumerate(user_tweets, 1):
#                     print(f"{idx}. {tweet['content']}")
#                 idx_to_update = int(input("Select the tweet number to update: ")) - 1
#                 if 0 <= idx_to_update < len(user_tweets):
#                     new_content = input("Enter new content: ")
#                     user_tweets[idx_to_update]['content'] = new_content
#                     print("Tweet updated successfully.")
#                 else:
#                     print("Invalid tweet selection.")
#             else:
#                 print("You have no tweets to update.")

#         elif choice == '4':
#             print("\nYour Tweets:")
#             user_tweets = [t for t in tweets if t['author'] == username]
#             if user_tweets:
#                 for idx, tweet in enumerate(user_tweets, 1):
#                     print(f"{idx}. {tweet['content']}")
#                 idx_to_delete = int(input("Select the tweet number to delete: ")) - 1
#                 if 0 <= idx_to_delete < len(user_tweets):
#                     tweet_to_remove = user_tweets[idx_to_delete]
#                     tweets.remove(tweet_to_remove)
#                     print("Tweet deleted successfully.")
#                 else:
#                     print("Invalid tweet selection.")
#             else:
#                 print("You have no tweets to delete.")

#         elif choice == '5':
#             print("\nYour Tweets:")
#             user_tweets = [t for t in tweets if t['author'] == username]
#             if user_tweets:
#                 for idx, tweet in enumerate(user_tweets, 1):
#                     print(f"{idx}. {tweet['content']}")
#             else:
#                 print("You have no tweets.")

#         elif choice == '6':
#             print("Logging out...")
#             break

#         else:
#             print("Invalid option. Please try again.")

# if __name__ == "__main__":
#     auth_menu()

# def show_auth_menu():
#     print(menu_text.auth_menu)
#     option = input("Enter your option: ")

#     if option == "1":
#         if auth.register():
#             print("Check your email we send a verification code. Activate your email by menu 4.")
#         else:
#             print("Something went wrong")

#     elif option == "2":
#         if auth.login():
#             print("Welcome to main menu")
#             show_main_menu()
#         else:
#             print("Something went wrong")

#     elif option == "3":
#         ...

#     elif option == "4":

#         auth.activate_email()
        
#     else:
#         print("Invalid option")
#     return show_auth_menu()

# def show_main_menu():

#     print(menu_text.main_menu)
#     option = input("Enter your option: ")

#     if option == "1":
#        if crud.add_money():
#            print("Olgan qarzingiz bazaga saqlandi")
#        else:
#            print("Xatolik yuzaga keldi")

#     elif option == "2":
#         result = crud.show_moneys()
#         print(result)
    
#     elif option == "3":
#         result = crud.update_money()
#         print(result)

#     elif option == "4":
#         result = crud.delete_money()
#         print(result)

#     else:
#         print("Invalid option")
#     return show_main_menu()


# if __name__ == "__main__":
#     create_tables()
#     logut_all()
#     show_auth_menu()
